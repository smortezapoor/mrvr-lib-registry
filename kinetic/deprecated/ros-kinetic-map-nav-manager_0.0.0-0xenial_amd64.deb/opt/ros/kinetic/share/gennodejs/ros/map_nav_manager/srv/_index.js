
"use strict";

let SetFilename = require('./SetFilename.js')

module.exports = {
  SetFilename: SetFilename,
};
