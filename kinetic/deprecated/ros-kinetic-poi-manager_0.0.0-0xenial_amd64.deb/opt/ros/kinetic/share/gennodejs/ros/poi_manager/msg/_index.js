
"use strict";

let LabeledPose = require('./LabeledPose.js');

module.exports = {
  LabeledPose: LabeledPose,
};
