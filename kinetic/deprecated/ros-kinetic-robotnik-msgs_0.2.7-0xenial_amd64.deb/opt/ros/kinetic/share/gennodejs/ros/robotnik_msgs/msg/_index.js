
"use strict";

let BoolArray = require('./BoolArray.js');
let Registers = require('./Registers.js');
let alarmsmonitor = require('./alarmsmonitor.js');
let Axis = require('./Axis.js');
let MotorsStatus = require('./MotorsStatus.js');
let MotorStatus = require('./MotorStatus.js');
let LaserMode = require('./LaserMode.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let ptz = require('./ptz.js');
let AlarmSensor = require('./AlarmSensor.js');
let QueryAlarm = require('./QueryAlarm.js');
let SubState = require('./SubState.js');
let Data = require('./Data.js');
let MotorsStatusDifferential = require('./MotorsStatusDifferential.js');
let alarmmonitor = require('./alarmmonitor.js');
let MotorHeadingOffset = require('./MotorHeadingOffset.js');
let Interfaces = require('./Interfaces.js');
let State = require('./State.js');
let encoders = require('./encoders.js');
let BatteryStatus = require('./BatteryStatus.js');
let Register = require('./Register.js');
let SafetyModuleStatus = require('./SafetyModuleStatus.js');
let inputs_outputs = require('./inputs_outputs.js');
let named_input_output = require('./named_input_output.js');
let Alarms = require('./Alarms.js');
let InverterStatus = require('./InverterStatus.js');
let LaserStatus = require('./LaserStatus.js');
let BatteryDockingStatusStamped = require('./BatteryDockingStatusStamped.js');
let ElevatorStatus = require('./ElevatorStatus.js');
let Cartesian_Euler_pose = require('./Cartesian_Euler_pose.js');
let StringArray = require('./StringArray.js');
let ElevatorAction = require('./ElevatorAction.js');
let RobotnikMotorsStatus = require('./RobotnikMotorsStatus.js');
let BatteryStatusStamped = require('./BatteryStatusStamped.js');
let named_inputs_outputs = require('./named_inputs_outputs.js');
let Pose2DArray = require('./Pose2DArray.js');
let BatteryDockingStatus = require('./BatteryDockingStatus.js');
let MotorPID = require('./MotorPID.js');
let SetElevatorActionFeedback = require('./SetElevatorActionFeedback.js');
let SetElevatorFeedback = require('./SetElevatorFeedback.js');
let SetElevatorGoal = require('./SetElevatorGoal.js');
let SetElevatorResult = require('./SetElevatorResult.js');
let SetElevatorActionGoal = require('./SetElevatorActionGoal.js');
let SetElevatorAction = require('./SetElevatorAction.js');
let SetElevatorActionResult = require('./SetElevatorActionResult.js');

module.exports = {
  BoolArray: BoolArray,
  Registers: Registers,
  alarmsmonitor: alarmsmonitor,
  Axis: Axis,
  MotorsStatus: MotorsStatus,
  MotorStatus: MotorStatus,
  LaserMode: LaserMode,
  Pose2DStamped: Pose2DStamped,
  ptz: ptz,
  AlarmSensor: AlarmSensor,
  QueryAlarm: QueryAlarm,
  SubState: SubState,
  Data: Data,
  MotorsStatusDifferential: MotorsStatusDifferential,
  alarmmonitor: alarmmonitor,
  MotorHeadingOffset: MotorHeadingOffset,
  Interfaces: Interfaces,
  State: State,
  encoders: encoders,
  BatteryStatus: BatteryStatus,
  Register: Register,
  SafetyModuleStatus: SafetyModuleStatus,
  inputs_outputs: inputs_outputs,
  named_input_output: named_input_output,
  Alarms: Alarms,
  InverterStatus: InverterStatus,
  LaserStatus: LaserStatus,
  BatteryDockingStatusStamped: BatteryDockingStatusStamped,
  ElevatorStatus: ElevatorStatus,
  Cartesian_Euler_pose: Cartesian_Euler_pose,
  StringArray: StringArray,
  ElevatorAction: ElevatorAction,
  RobotnikMotorsStatus: RobotnikMotorsStatus,
  BatteryStatusStamped: BatteryStatusStamped,
  named_inputs_outputs: named_inputs_outputs,
  Pose2DArray: Pose2DArray,
  BatteryDockingStatus: BatteryDockingStatus,
  MotorPID: MotorPID,
  SetElevatorActionFeedback: SetElevatorActionFeedback,
  SetElevatorFeedback: SetElevatorFeedback,
  SetElevatorGoal: SetElevatorGoal,
  SetElevatorResult: SetElevatorResult,
  SetElevatorActionGoal: SetElevatorActionGoal,
  SetElevatorAction: SetElevatorAction,
  SetElevatorActionResult: SetElevatorActionResult,
};
