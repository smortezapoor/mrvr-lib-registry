
"use strict";

let Disk = require('./Disk.js');
let DiagnosticNET = require('./DiagnosticNET.js');
let DiagnosticCPUUsage = require('./DiagnosticCPUUsage.js');
let DiagnosticHDD = require('./DiagnosticHDD.js');
let DiagnosticMEM = require('./DiagnosticMEM.js');
let CPUTemperatureStatus = require('./CPUTemperatureStatus.js');
let DiagnosticCPUTemperature = require('./DiagnosticCPUTemperature.js');
let Interface = require('./Interface.js');
let MEMStatus = require('./MEMStatus.js');
let NetStatus = require('./NetStatus.js');
let Diagnostic = require('./Diagnostic.js');
let HDDStatus = require('./HDDStatus.js');
let Memory = require('./Memory.js');
let CoreTemp = require('./CoreTemp.js');
let CPUUsageStatus = require('./CPUUsageStatus.js');
let CoreUsage = require('./CoreUsage.js');
let Disk = require('./Disk.js');
let DiagnosticNET = require('./DiagnosticNET.js');
let DiagnosticCPUUsage = require('./DiagnosticCPUUsage.js');
let DiagnosticHDD = require('./DiagnosticHDD.js');
let DiagnosticMEM = require('./DiagnosticMEM.js');
let CPUTemperatureStatus = require('./CPUTemperatureStatus.js');
let DiagnosticCPUTemperature = require('./DiagnosticCPUTemperature.js');
let Interface = require('./Interface.js');
let MEMStatus = require('./MEMStatus.js');
let NetStatus = require('./NetStatus.js');
let Diagnostic = require('./Diagnostic.js');
let HDDStatus = require('./HDDStatus.js');
let Memory = require('./Memory.js');
let CoreTemp = require('./CoreTemp.js');
let CPUUsageStatus = require('./CPUUsageStatus.js');
let CoreUsage = require('./CoreUsage.js');

module.exports = {
  Disk: Disk,
  DiagnosticNET: DiagnosticNET,
  DiagnosticCPUUsage: DiagnosticCPUUsage,
  DiagnosticHDD: DiagnosticHDD,
  DiagnosticMEM: DiagnosticMEM,
  CPUTemperatureStatus: CPUTemperatureStatus,
  DiagnosticCPUTemperature: DiagnosticCPUTemperature,
  Interface: Interface,
  MEMStatus: MEMStatus,
  NetStatus: NetStatus,
  Diagnostic: Diagnostic,
  HDDStatus: HDDStatus,
  Memory: Memory,
  CoreTemp: CoreTemp,
  CPUUsageStatus: CPUUsageStatus,
  CoreUsage: CoreUsage,
  Disk: Disk,
  DiagnosticNET: DiagnosticNET,
  DiagnosticCPUUsage: DiagnosticCPUUsage,
  DiagnosticHDD: DiagnosticHDD,
  DiagnosticMEM: DiagnosticMEM,
  CPUTemperatureStatus: CPUTemperatureStatus,
  DiagnosticCPUTemperature: DiagnosticCPUTemperature,
  Interface: Interface,
  MEMStatus: MEMStatus,
  NetStatus: NetStatus,
  Diagnostic: Diagnostic,
  HDDStatus: HDDStatus,
  Memory: Memory,
  CoreTemp: CoreTemp,
  CPUUsageStatus: CPUUsageStatus,
  CoreUsage: CoreUsage,
};
