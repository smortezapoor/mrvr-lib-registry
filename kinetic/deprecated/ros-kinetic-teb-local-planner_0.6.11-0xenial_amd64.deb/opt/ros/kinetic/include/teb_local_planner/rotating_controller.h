#ifndef ROTATING_CONTROLLER_H_
#define ROTATING_CONTROLLER_H_

#include <tf/tf.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_listener.h>

namespace teb_local_planner {

class RotatingController {
public:
  RotatingController() = default;
  virtual ~RotatingController() = default;

  void initialize(ros::NodeHandle &nh);

  void setParams(double max_vel_theta, double acc_lim_theta,
                 double yaw_goal_tolerance, double sim_period);

  void setGoalPose(const geometry_msgs::PoseStamped &goal_pose);

  bool rotateToGoalPose(const tf::Stamped<tf::Pose> &robot_pose,
                        const tf::Stamped<tf::Pose> &robot_vel,
                        geometry_msgs::Twist &cmd_vel);

  bool isGoalPoseReached(const tf::Stamped<tf::Pose> &robot_pose);

  void visualize();

private:
  ros::Publisher goal_pose_pub_;

  geometry_msgs::PoseStamped goal_pose_;
  double goal_th_;

  double max_vel_theta_, acc_lim_theta_, yaw_goal_tolerance_, sim_period_;
};

} // namespace teb_local_planner

#endif // ROTATING_CONTROLLER_H_
