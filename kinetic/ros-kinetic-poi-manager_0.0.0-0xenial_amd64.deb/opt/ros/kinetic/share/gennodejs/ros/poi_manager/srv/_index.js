
"use strict";

let ReadPOIs = require('./ReadPOIs.js')
let UpdatePOIs = require('./UpdatePOIs.js')

module.exports = {
  ReadPOIs: ReadPOIs,
  UpdatePOIs: UpdatePOIs,
};
