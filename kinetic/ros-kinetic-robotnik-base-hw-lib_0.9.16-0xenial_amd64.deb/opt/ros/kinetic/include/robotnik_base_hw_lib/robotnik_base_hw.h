/** \file robotnik_base_hw_lib.h
 * \author Robotnik Automation S.L.L.
 * \version 2.0
 * \date    2012
 *
 * \brief class for the RB1_base CAN multi-axis controller
 *
 * (C) Robotnik Automation, SLL
 */

#ifndef _ROBOTNIK_BASE_HW_ROBOTNIK_BASE_HW_H_
#define _ROBOTNIK_BASE_HW_ROBOTNIK_BASE_HW_H_

#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <vector>

#include <ros/ros.h>
#include <std_msgs/Float32.h>  // battery, gyro, and steering angle
#include <std_msgs/Float64.h>  // battery, gyro, and steering angle
#include <std_msgs/Int32.h>
#include <std_msgs/Bool.h>
#include <std_msgs/String.h>
#include <std_srvs/Trigger.h>
#include <std_srvs/SetBool.h>
#include <sensor_msgs/JointState.h>

#include <self_test/self_test.h>
#include <diagnostic_msgs/DiagnosticStatus.h>
#include <diagnostic_updater/diagnostic_updater.h>
#include <diagnostic_updater/update_functions.h>
#include <diagnostic_updater/DiagnosticStatusWrapper.h>
#include <diagnostic_updater/publisher.h>

#include <robotnik_base_hw_lib/Component.h>
#include <robotnik_base_hw_lib/MotorPosition.h>
#include <robotnik_base_hw_lib/MotorVelocity.h>
#include <robotnik_base_hw_lib/BatteryEstimation.h>
#include <robotnik_base_hw_lib/MotorDrive.h>
#include <robotnik_msgs/RobotnikMotorsStatus.h>
#include <robotnik_msgs/MotorStatus.h>
#include <robotnik_msgs/State.h>
#include <robotnik_msgs/BatteryStatus.h>
#include <robotnik_msgs/SetMotorStatus.h>
#include <robotnik_msgs/inputs_outputs.h>
#include <robotnik_msgs/set_digital_output.h>
#include <robotnik_msgs/BatteryDockingStatus.h>
#include <robotnik_msgs/BatteryDockingStatusStamped.h>

// ROS_CONTROL includes
#include <hardware_interface/robot_hw.h>
#include <hardware_interface/joint_state_interface.h>
#include <hardware_interface/joint_command_interface.h>
#include <hardware_interface/actuator_state_interface.h>
#include <hardware_interface/actuator_command_interface.h>
#include <controller_manager/controller_manager.h>

#include <joint_limits_interface/joint_limits.h>
#include <joint_limits_interface/joint_limits_interface.h>
#include <joint_limits_interface/joint_limits_rosparam.h>
#include <joint_limits_interface/joint_limits_urdf.h>

#include <urdf/model.h>

#define MAX_CTRL_PARAMS 9

#define ROBOTNIK_INIT_HZ 1.0             // motor component frequency during init
#define ROBOTNIK_DEFAULT_HZ 50.0         // motor component frequency during running
#define MAX_NUMBER_OF_READ_CAN_MSGS 100  // max number read per iteration
#define BATTERY_DOCKING_DEFAULT_CONTACT_RELAY_INPUT 17
#define BATTERY_DOCKING_DEFAULT_CHARGER_RELAY_OUTPUT 10
#define BATTERY_DOCKING_DEFAULT_CURRENT_CONSUMPTION_INPUT 4
#define BATTERY_DOCKING_DEFAULT_MODE "automatic_hw"

struct Joint
{
  double position;
  double velocity;
  double effort;
  double command;
};

// Saves the data related to docking station battery charge
typedef struct BatteryDocking
{
  //! mode of operation
  std::string operation_mode;
  //! input number to read the contact status
  int contact_relay_input_number;
  //! output number to switch on/off the battery charge
  int charger_relay_output_number;
  //! input number to read the charging intensity
  int charge_current_input_number;

  //! current status of the battery contact relay
  bool contact_relay_status;
  //! current status of the battery charger relay
  bool charger_relay_status;
  //! current input amperage
  double battery_current;

  //! current input in volts
  std::vector<double> battery_current_raw_vector;
  //! index of the vector
  int battery_current_raw_index;
  //! size of the vector
  int battery_current_raw_size;
  //! constant to convert volts to ampers
  double volts_to_ampers;
  //! sensor offset in volts
  double sensor_offset;

  //! desired status of the battery contact relay (depends on the operation_mode)
  bool desired_relay_status;

} BatteryDocking;

class RobotnikBaseHW : public hardware_interface::RobotHW, public Component
{
private:
  self_test::TestRunner self_test_;
  ros::NodeHandle node_handle_;
  ros::NodeHandle private_node_handle_;
  double desired_freq_;
  diagnostic_updater::Updater diagnostic_;  // General status diagnostic updater

  //! Topic to publish the current motor counts
  ros::Publisher component_state_pub_;
  ros::Publisher motor_status_pub_;
  ros::Publisher battery_voltage_pub_;
  ros::Publisher estop_pub_;
  ros::Publisher battery_alarm_pub_;
  ros::Publisher io_pub_;
  ros::Publisher battery_data_pub_;
  ros::Publisher docking_battery_status_pub_;

  // Services
  ros::ServiceServer set_motor_status_;
  ros::ServiceServer set_digital_output_;
  ros::ServiceServer send_to_home_;
  ros::ServiceServer set_charger_relay_;
  //! Can device port
  std::string can_dev_;
  //! CAN device
  PCan* can_device_;
  //! motor for steering
  std::vector<MotorDrive*> motor_;
  std::vector<MotorPosition*> motor_position_;
  std::vector<MotorVelocity*> motor_velocity_;

  std::vector<int> motor_position_can_id_;
  std::vector<int> motor_velocity_can_id_;

  std::vector<int> motor_spin_;

  std::vector<std::string> joint_position_name_;
  std::vector<std::string> joint_velocity_name_;
  std::vector<std::string> joint_name_;

  std::vector<std::string> joint_type_;

  std::vector<int> joint_can_id_;
  std::vector<int> joint_offset_;
  std::vector<int> joint_spin_;
  std::vector<double> joint_gearbox_ratio_;
  std::vector<bool> joint_home_required_;
  int home_method_;
  std::vector<bool> joint_home_at_startup_;
  std::vector<int> low_position_limit_;
  std::vector<int> high_position_limit_;

  //! kinematic control parameters
  std::vector<KinematicParams> kinematic_params_;
  //! control parameters
  ControlParams control_params_;

  double wheel_diameter_;
  double gearbox_ratio_;
  bool has_encoder_;
  double encoder_factor_;
  bool check_hit_position_limit_;

  // Battery estimation
  BatteryEstimation battery_estimator_;

  int num_inputs_per_driver_;
  int num_analog_inputs_per_driver_;
  int num_outputs_per_driver_;

  float max_value_discharging_;
  float min_value_charging_;

  //! Voltage level to raise an alarm
  double battery_alarm_voltage_;

  bool running;
  //! Flag to set the status of can comm
  bool can_communication;
  //! Saves the time of the last command received
  ros::Time last_command_time;

  int publish_status_counter;
  int publish_status_freq;  // number of loop cycles to publish the status

  // ROS CONTROL STUFF
  hardware_interface::JointStateInterface joint_state_interface_;
  hardware_interface::PositionJointInterface position_joint_interface_;
  hardware_interface::VelocityJointInterface velocity_joint_interface_;

  joint_limits_interface::PositionJointSaturationInterface position_joint_sat_limits_interface_;
  joint_limits_interface::VelocityJointSaturationInterface velocity_joint_sat_limits_interface_;

  // Joint limits interfaces - Soft limits
  joint_limits_interface::PositionJointSoftLimitsInterface position_joint_soft_limits_interface_;
  joint_limits_interface::VelocityJointSoftLimitsInterface velocity_joint_soft_limits_interface_;

  std::vector<Joint> joint_position_;
  std::vector<Joint> joint_velocity_;

  boost::shared_ptr<urdf::Model> urdf_model_;
  std::string urdf_model_as_string_;

  std::string name_;                                               // TODO set node name
  bool use_rosparam_joint_limits_, use_soft_limits_if_available_;  // TODO read from params

  ros::Duration recovery_attempt_period_;   // period between recovery attempts
  ros::Duration show_battery_info_period_;  // period between publishing battery info
  ros::Time last_recovery_attempt_time_;    // timestamp of last recovery attempt
  ros::Time first_battery_time_;            // timestamp of first comprobation about is battery charging
  ros::Time last_battery_time_;             // timestamp of last comprobation about is battery charging
  ros::Time last_battery_info_time_;        // timestamp of last published battery info
  robotnik_msgs::inputs_outputs io_;        // global inputs/outputs gathering all the drives

  bool e_stop_;

  BatteryDocking battery_docking_;  // saves data for the docking battery charge
  std::string battery_last_operation_mode_; // saves the last operation_mode
  
  bool read_voltage_from_analog_input_;            // flag to read the voltage from an analog input
  int voltage_analog_input_number_;                // analog input number to get the voltage
  double k_voltage_divider_;                       // constanto to convert the value from the input to the correct one
  std::vector<double> battery_voltage_raw_vector;  // current input in volts
  std::vector<double> battery_voltage_vector;      // filtered input in volts
  int battery_voltage_raw_index;                   // index of the vector
  double k_battery_voltage_offset_;  // Offset applied to the battery read from the motordrive. (Calculated REAL
                                     // MEASUREMENT - MOTORDRIVE OUTPUT)
  bool inverted_contact_relay_input_; // flag to invert the battery contact relay driver input
  double charging_current_offset_; // This current offset avoids switching between charging and not charging 
                                   // when the station only privides current to stay in the same battery level.
                                   // This value should be between 0.0 - 0.5

public:
  RobotnikBaseHW(ros::NodeHandle h);

  /*!	\fn RobotnikBaseHW::~RobotnikBaseHW()
   * 	\brief Public destructor
   */
  ~RobotnikBaseHW();

  /*!	\fn int RobotnikBaseHW::start()
   * 	\brief Start Controller
   */
  // int start();

  /*!	\fn RobotnikBaseHW::stop()
   * 	\brief Stop Controller
   */
  // int stop();

  // Component Stuff
  Component::ReturnValue Setup();

  Component::ReturnValue ShutDown();

  Component::ReturnValue Start();

  Component::ReturnValue Stop();

  void InitState();
  void StandbyState();
  void ReadyState();
  void EmergencyState();
  void FailureState();
  void RestartState();
  void AllState();

  Component::ReturnValue update();

  int waitToBeReady();

  bool InitSystem();

  bool IsSystemReady();

  bool HasToHome();

  bool SendToHome(bool force_home);

  bool IsHomed();

  int setMotorsToRunningFrequency();
  //! disables the motors (quick stop)
  void disableMotors();
  //! enables the motors (operation enabled)
  void enableMotors();

  void sendZeroToMotors();

  /*!	\fn RobotnikBaseHW::connectTest()
   * 	\brief Test to connect to Motors
   */
  void connectTest(diagnostic_updater::DiagnosticStatusWrapper& status);

  /*
   *\brief Checks the status of the controller. Diagnostics
   *
   */
  void controllerDiagnostic(diagnostic_updater::DiagnosticStatusWrapper& stat);

  /*! \fn void controllerStatusPublishing()
   * \brief Publish Motors Status Topics
   *
   */
  void controllerStatusPublishing();

  ////////////////////////////////////////////////////////////////////////
  // PUBLIC FUNCTIONS

  /*!	\fn void RobotnikBaseHW::toggleMotorPower(unsigned char val)
   *	\brief Switches on/off the motor
   */
  void toggleMotorPower(unsigned char val);

  /*! \fn int readCANMessages()
   *	\brief Read messages from CAN bus
   *	\return -1 if ERROR
   *	\return 0 if OK
   */
  int readCANMessages();

  // Method readAndPublish()
  int readAndPublish();

  bool spin();

  /*! \fn  bool setMotorStatus(RobotnikBaseHW::SetMotorStatus::Request &req, RobotnikBaseHW::SetMotorStatus::Response
   * &res )
   * Sets the odometry of the robot
   */
  bool setMotorStatus(robotnik_msgs::SetMotorStatus::Request& req, robotnik_msgs::SetMotorStatus::Response& res);

  // Set Motor Digital Output
  bool setDigitalOutput(int number, bool value);

  // Set Motor Digital Output
  bool setDigitalOutputSrvCallback(robotnik_msgs::set_digital_output::Request& request,
                                   robotnik_msgs::set_digital_output::Response& response);

  bool sendToHomeSrvCallback(std_srvs::Trigger::Request& request, std_srvs::Trigger::Response& response);

  // Charger Relay Service Cb
  bool setChargerRelaySrvCallback(std_srvs::SetBool::Request& request, std_srvs::SetBool::Response& response);

  // Get Digital Output status by number
  bool getDigitalOutput(int iOutput);

  // Get Digital Input status by number
  bool getDigitalInput(int iInput);
  // Get Analog Input status by number
  double getAnalogInput(int iInput);

  /*! \fn  double encoderCountsToAngle(int counts)
   *  Converts absolute encoder counts into angle
   *  \return converted angle in radians
   */
  double encoderCountsToAngle(int counts);

  // ROS_CONTROL STUFF
  /** \brief Read the state from the robot hardware. */
  void read(ros::Duration& elapsed_time);

  /** \brief write the command to the robot hardware. */
  void write(ros::Duration& elapsed_time);

  void enforceLimits(ros::Duration& period);
  void resetLimits();

  void initHardwareInterface();

  void loadURDF(ros::NodeHandle& nh, std::string param_name);

  bool registerJointLimits(const boost::shared_ptr<urdf::Model> urdf_model, const std::string& joint_name,
                           const hardware_interface::JointHandle& joint_handle);

  bool RestartCan();
  void createMotorDrives();
  void destroyMotorDrives();

  // Performs battery state and battery docking control
  void batteryControl();
  // Initializes all the data related to battery control
  void initBatteryControlData();
  // Processes the raw value from the driver
  void processCurrentConsumptionRaw(double value);
  // gets the battery current in amperes
  double getBatteryCurrent();
  // processes battery raw values from driver
  void processBatteryVoltageRaw(double value);
  // gets the processed battery voltage
  double getBatteryVoltage();

public:
  bool isEStopEnabled();
  bool isSafetyEnabled();
};

#endif  // _ROBOTNIK_BASE_HW_ROBOTNIK_BASE_HW_H_
