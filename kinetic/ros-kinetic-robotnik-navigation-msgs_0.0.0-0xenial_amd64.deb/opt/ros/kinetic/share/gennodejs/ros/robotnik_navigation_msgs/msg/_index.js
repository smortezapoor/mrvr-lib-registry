
"use strict";

let PoseStampedArray = require('./PoseStampedArray.js');
let DockActionResult = require('./DockActionResult.js');
let MoveActionGoal = require('./MoveActionGoal.js');
let DockGoal = require('./DockGoal.js');
let DockResult = require('./DockResult.js');
let DockActionGoal = require('./DockActionGoal.js');
let MoveGoal = require('./MoveGoal.js');
let MoveActionFeedback = require('./MoveActionFeedback.js');
let MoveAction = require('./MoveAction.js');
let MoveResult = require('./MoveResult.js');
let DockAction = require('./DockAction.js');
let MoveActionResult = require('./MoveActionResult.js');
let DockActionFeedback = require('./DockActionFeedback.js');
let DockFeedback = require('./DockFeedback.js');
let MoveFeedback = require('./MoveFeedback.js');

module.exports = {
  PoseStampedArray: PoseStampedArray,
  DockActionResult: DockActionResult,
  MoveActionGoal: MoveActionGoal,
  DockGoal: DockGoal,
  DockResult: DockResult,
  DockActionGoal: DockActionGoal,
  MoveGoal: MoveGoal,
  MoveActionFeedback: MoveActionFeedback,
  MoveAction: MoveAction,
  MoveResult: MoveResult,
  DockAction: DockAction,
  MoveActionResult: MoveActionResult,
  DockActionFeedback: DockActionFeedback,
  DockFeedback: DockFeedback,
  MoveFeedback: MoveFeedback,
};
