
"use strict";

let DiagnosticNET = require('./DiagnosticNET.js');
let DiagnosticMEM = require('./DiagnosticMEM.js');
let Interface = require('./Interface.js');
let HDDStatus = require('./HDDStatus.js');
let CoreUsage = require('./CoreUsage.js');
let NetStatus = require('./NetStatus.js');
let CPUTemperatureStatus = require('./CPUTemperatureStatus.js');
let CoreTemp = require('./CoreTemp.js');
let DiagnosticCPUTemperature = require('./DiagnosticCPUTemperature.js');
let CPUUsageStatus = require('./CPUUsageStatus.js');
let DiagnosticHDD = require('./DiagnosticHDD.js');
let Disk = require('./Disk.js');
let DiagnosticCPUUsage = require('./DiagnosticCPUUsage.js');
let Diagnostic = require('./Diagnostic.js');
let MEMStatus = require('./MEMStatus.js');
let Memory = require('./Memory.js');
let DiagnosticNET = require('./DiagnosticNET.js');
let DiagnosticMEM = require('./DiagnosticMEM.js');
let Interface = require('./Interface.js');
let HDDStatus = require('./HDDStatus.js');
let CoreUsage = require('./CoreUsage.js');
let NetStatus = require('./NetStatus.js');
let CPUTemperatureStatus = require('./CPUTemperatureStatus.js');
let CoreTemp = require('./CoreTemp.js');
let DiagnosticCPUTemperature = require('./DiagnosticCPUTemperature.js');
let CPUUsageStatus = require('./CPUUsageStatus.js');
let DiagnosticHDD = require('./DiagnosticHDD.js');
let Disk = require('./Disk.js');
let DiagnosticCPUUsage = require('./DiagnosticCPUUsage.js');
let Diagnostic = require('./Diagnostic.js');
let MEMStatus = require('./MEMStatus.js');
let Memory = require('./Memory.js');

module.exports = {
  DiagnosticNET: DiagnosticNET,
  DiagnosticMEM: DiagnosticMEM,
  Interface: Interface,
  HDDStatus: HDDStatus,
  CoreUsage: CoreUsage,
  NetStatus: NetStatus,
  CPUTemperatureStatus: CPUTemperatureStatus,
  CoreTemp: CoreTemp,
  DiagnosticCPUTemperature: DiagnosticCPUTemperature,
  CPUUsageStatus: CPUUsageStatus,
  DiagnosticHDD: DiagnosticHDD,
  Disk: Disk,
  DiagnosticCPUUsage: DiagnosticCPUUsage,
  Diagnostic: Diagnostic,
  MEMStatus: MEMStatus,
  Memory: Memory,
  DiagnosticNET: DiagnosticNET,
  DiagnosticMEM: DiagnosticMEM,
  Interface: Interface,
  HDDStatus: HDDStatus,
  CoreUsage: CoreUsage,
  NetStatus: NetStatus,
  CPUTemperatureStatus: CPUTemperatureStatus,
  CoreTemp: CoreTemp,
  DiagnosticCPUTemperature: DiagnosticCPUTemperature,
  CPUUsageStatus: CPUUsageStatus,
  DiagnosticHDD: DiagnosticHDD,
  Disk: Disk,
  DiagnosticCPUUsage: DiagnosticCPUUsage,
  Diagnostic: Diagnostic,
  MEMStatus: MEMStatus,
  Memory: Memory,
};
