
"use strict";

let GetEnvironments = require('./GetEnvironments.js')
let AddPOI_params = require('./AddPOI_params.js')
let ReadPOIs = require('./ReadPOIs.js')
let DeletePOI = require('./DeletePOI.js')
let DeleteEnvironment = require('./DeleteEnvironment.js')
let GetPOI_params = require('./GetPOI_params.js')
let GetPoseTrigger = require('./GetPoseTrigger.js')
let AddPOIs = require('./AddPOIs.js')
let AddPOI = require('./AddPOI.js')
let GetPOI = require('./GetPOI.js')
let GetPOIs = require('./GetPOIs.js')

module.exports = {
  GetEnvironments: GetEnvironments,
  AddPOI_params: AddPOI_params,
  ReadPOIs: ReadPOIs,
  DeletePOI: DeletePOI,
  DeleteEnvironment: DeleteEnvironment,
  GetPOI_params: GetPOI_params,
  GetPoseTrigger: GetPoseTrigger,
  AddPOIs: AddPOIs,
  AddPOI: AddPOI,
  GetPOI: GetPOI,
  GetPOIs: GetPOIs,
};
