
"use strict";

let State = require('./State.js');
let MotorsStatusDifferential = require('./MotorsStatusDifferential.js');
let SafetyModuleStatus = require('./SafetyModuleStatus.js');
let Interfaces = require('./Interfaces.js');
let LaserStatus = require('./LaserStatus.js');
let ptz = require('./ptz.js');
let BatteryDockingStatusStamped = require('./BatteryDockingStatusStamped.js');
let BatteryStatus = require('./BatteryStatus.js');
let named_inputs_outputs = require('./named_inputs_outputs.js');
let RobotnikMotorsStatus = require('./RobotnikMotorsStatus.js');
let ElevatorStatus = require('./ElevatorStatus.js');
let BatteryDockingStatus = require('./BatteryDockingStatus.js');
let Register = require('./Register.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let alarmmonitor = require('./alarmmonitor.js');
let InverterStatus = require('./InverterStatus.js');
let MotorPID = require('./MotorPID.js');
let Cartesian_Euler_pose = require('./Cartesian_Euler_pose.js');
let PresenceSensorArray = require('./PresenceSensorArray.js');
let alarmsmonitor = require('./alarmsmonitor.js');
let encoders = require('./encoders.js');
let LaserMode = require('./LaserMode.js');
let StringArray = require('./StringArray.js');
let inputs_outputs = require('./inputs_outputs.js');
let ReturnMessage = require('./ReturnMessage.js');
let Pose2DArray = require('./Pose2DArray.js');
let Axis = require('./Axis.js');
let AlarmSensor = require('./AlarmSensor.js');
let BatteryStatusStamped = require('./BatteryStatusStamped.js');
let Alarms = require('./Alarms.js');
let named_input_output = require('./named_input_output.js');
let MotorStatus = require('./MotorStatus.js');
let Registers = require('./Registers.js');
let BoolArray = require('./BoolArray.js');
let QueryAlarm = require('./QueryAlarm.js');
let MotorsStatus = require('./MotorsStatus.js');
let PresenceSensor = require('./PresenceSensor.js');
let SubState = require('./SubState.js');
let MotorHeadingOffset = require('./MotorHeadingOffset.js');
let Data = require('./Data.js');
let ElevatorAction = require('./ElevatorAction.js');
let SetElevatorResult = require('./SetElevatorResult.js');
let SetElevatorActionFeedback = require('./SetElevatorActionFeedback.js');
let SetElevatorActionResult = require('./SetElevatorActionResult.js');
let SetElevatorAction = require('./SetElevatorAction.js');
let SetElevatorFeedback = require('./SetElevatorFeedback.js');
let SetElevatorGoal = require('./SetElevatorGoal.js');
let SetElevatorActionGoal = require('./SetElevatorActionGoal.js');

module.exports = {
  State: State,
  MotorsStatusDifferential: MotorsStatusDifferential,
  SafetyModuleStatus: SafetyModuleStatus,
  Interfaces: Interfaces,
  LaserStatus: LaserStatus,
  ptz: ptz,
  BatteryDockingStatusStamped: BatteryDockingStatusStamped,
  BatteryStatus: BatteryStatus,
  named_inputs_outputs: named_inputs_outputs,
  RobotnikMotorsStatus: RobotnikMotorsStatus,
  ElevatorStatus: ElevatorStatus,
  BatteryDockingStatus: BatteryDockingStatus,
  Register: Register,
  Pose2DStamped: Pose2DStamped,
  alarmmonitor: alarmmonitor,
  InverterStatus: InverterStatus,
  MotorPID: MotorPID,
  Cartesian_Euler_pose: Cartesian_Euler_pose,
  PresenceSensorArray: PresenceSensorArray,
  alarmsmonitor: alarmsmonitor,
  encoders: encoders,
  LaserMode: LaserMode,
  StringArray: StringArray,
  inputs_outputs: inputs_outputs,
  ReturnMessage: ReturnMessage,
  Pose2DArray: Pose2DArray,
  Axis: Axis,
  AlarmSensor: AlarmSensor,
  BatteryStatusStamped: BatteryStatusStamped,
  Alarms: Alarms,
  named_input_output: named_input_output,
  MotorStatus: MotorStatus,
  Registers: Registers,
  BoolArray: BoolArray,
  QueryAlarm: QueryAlarm,
  MotorsStatus: MotorsStatus,
  PresenceSensor: PresenceSensor,
  SubState: SubState,
  MotorHeadingOffset: MotorHeadingOffset,
  Data: Data,
  ElevatorAction: ElevatorAction,
  SetElevatorResult: SetElevatorResult,
  SetElevatorActionFeedback: SetElevatorActionFeedback,
  SetElevatorActionResult: SetElevatorActionResult,
  SetElevatorAction: SetElevatorAction,
  SetElevatorFeedback: SetElevatorFeedback,
  SetElevatorGoal: SetElevatorGoal,
  SetElevatorActionGoal: SetElevatorActionGoal,
};
