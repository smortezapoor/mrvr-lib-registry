#!/bin/bash

echo "THIS SCRIPT HAS TO BE RUN JUST ONCE! otherwise delete the added to the .bashrc"

config_folder=`rospack find summit_xl_bringup`/env
target_folder=~
robot_params_file=robot_params.env
autorun_file=autorun.bash

cp -v $config_folder/$robot_params_file $target_folder 
cp -v $config_folder/$autorun_file $target_folder

echo "source $target_folder/robot_params.env" >> ~/.bashrc
echo "source $target_folder/autorun.bash" >> ~/.bashrc

