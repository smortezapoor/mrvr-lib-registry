#!/bin/bash
# Command to start VNC server on arm
ssh root@192.168.0.210 bash -c './start_vnc.sh'
