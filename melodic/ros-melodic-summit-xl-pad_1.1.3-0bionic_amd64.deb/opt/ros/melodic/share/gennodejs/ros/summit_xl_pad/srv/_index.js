
"use strict";

let enable_disable_pad = require('./enable_disable_pad.js')

module.exports = {
  enable_disable_pad: enable_disable_pad,
};
